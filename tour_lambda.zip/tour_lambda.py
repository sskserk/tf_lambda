
def get_handler(event, context):

    return { "message": "GET_HANDLER" }

def post_handler(event, context):
    return { "message": "POST_HANDLER" }
